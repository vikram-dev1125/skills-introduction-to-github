//Simulate various situations within Chessitalism Game

var players = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23];
var ratings = [1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500,1500, 1500, 1500, 1500];
var wealth = [1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000];
var K = 15;
var entropy = 0;
var spread = 0;

for (var k = 0; k < 10; k ++){
  playGame(5+(2*k));
  wealth = [1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000];
  spread = 0;
  ratings = [1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500,1500, 1500, 1500, 1500];
}


function playGame(n){
  for (var i = 0; i < 2; i++){
  var player1 = randomNumber(0,n);
  var player2 = randomNumber(0,n);
  while (player2 == player1){
    player2 = randomNumber(0,n);
  }
  var expectedScore = Math.round(1000 / (1 + Math.pow(10,((ratings[player2] - ratings[player1])/ 400))));
  var test = randomNumber(1,1000);
  if (test <= expectedScore){
    ratings[player1] = ratings[player1] + K * (1 - expectedScore/1000);
    ratings[player2] = ratings[player2] - K * (1 - expectedScore/1000);
    wealth[player1] = wealth[player1] + 20;
    wealth[player2] = wealth[player2] - 20;
  } else {
    ratings[player1] = ratings[player1] - K * ( expectedScore/1000);
    ratings[player2] = ratings[player2] + K * ( expectedScore/1000);
    wealth[player1] = wealth[player1] - 20;
    wealth[player2] = wealth[player2] + 20;
  }
  }
  var t = 0;
  while (t < n){
    spread = spread + Math.log(ratings[t]);
    console.log(ratings[t]);
    t++;

  }
  entropy = n*Math.log(1500) / spread;
  console.log(n + ":  " + entropy);
}
